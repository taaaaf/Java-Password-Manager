import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import java.security.MessageDigest;
import java.util.Arrays;

public class PasswordManagerLogicTest {
    
    private static final String PASSWORD = "testPassword123";
    private static UserData userData;
    private static byte[] encryptedData;
    private static Key aesKey;

    @BeforeClass
    public static void setUp() {
        userData = new UserData();
        userData.userRecords.add(new UserRecord("Label1", "Password1"));
        
        // Setup encryption key
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] key = digest.digest(PASSWORD.getBytes("UTF-8"));
            aesKey = new SecretKeySpec(key, "AES");
        } catch (Exception e) {
            fail("Error setting up encryption key: " + e.getMessage());
        }
    }

//    @Test
//    public void testSerializationAndDeserialization() {
//        byte[] serializedData = PasswordManagerLogic.serialize(userData);
//        assertNotNull("Serialized data should not be null", serializedData);
//
//        UserData deserializedUserData = (UserData) PasswordManagerLogic.deserialize(serializedData);
//        assertNotNull("Deserialized user data should not be null", deserializedUserData);
//
//        assertEquals("Deserialized user data should match the original user data size",
//                userData.userRecords.size(), deserializedUserData.userRecords.size());
//        assertEquals("Deserialized user data label should match the original label",
//                userData.userRecords.get(0).label, deserializedUserData.userRecords.get(0).label);
//        assertEquals("Deserialized user data password should match the original password",
//                userData.userRecords.get(0).password, deserializedUserData.userRecords.get(0).password);
//    }

    @Test
    public void testEncryptionDecryptionConsistency() {
        encryptedData = PasswordManagerLogic.encryptUserData(PASSWORD, userData);
        assertNotNull("Encrypted data should not be null", encryptedData);

        UserData decryptedUserData = PasswordManagerLogic.decryptUserData(encryptedData, PASSWORD);
        assertNotNull("Decrypted user data should not be null", decryptedUserData);

        assertEquals("Decrypted user data should match the original user data size",
                userData.userRecords.size(), decryptedUserData.userRecords.size());
        assertEquals("Decrypted user data label should match the original label",
                userData.userRecords.get(0).label, decryptedUserData.userRecords.get(0).label);
        assertEquals("Decrypted user data password should match the original password",
                userData.userRecords.get(0).password, decryptedUserData.userRecords.get(0).password);
    }
}
